# Design Evaluator Gate

A gate that flags weak UI output from non-designers (using Claude) at Carbonteq — by checking
**adherence to design principles**, not resemblance to exemplars. Every verdict cites a principle,
locates the violation, and gives a concrete fix. It **argues, it does not score**.

> Full design rationale: `~/Desktop/Design Dept/Resources/design-evaluator-gate-plan.md` and the
> implementation plan at `~/.claude/plans/…goofy-lemur.md`.

## How it works — perception, then judgment

```
/gate  (orchestrator skill)
  └─ DECOMPOSE (subagent)  →  MAP (subagent)  →  JUDGE (subagent)  →  assembled verdict
       perception only          observation→         verdict, argued,
       + hard-checks (real)      principle+tier       tier logic, exemplars
       + slop markers
```
Splitting perception from judgment is the point: Decompose commits to *observed facts* (measured,
not eyeballed), so Judge reasons against reality, not vibes — and failures are debuggable (you can see
which stage broke).

### The two-tier rubric (Eman-confirmed)
- **Constraint tier (near-auto-fail, measured):** C1 contrast (WCAG AA), C2 touch targets (24px hard).
- **C3 slop convergence (hybrid):** constraint-tier flag *only if* ≥3 markers co-occur **with** a
  constraint fail; otherwise a strong default-tier signal. A single marker never flags.
- **Default tier (breakable when controlled):** D1 hierarchy · D2 proximity · D3 alignment/spacing ·
  D4 typography · D5 restraint · D6 consistency · D8 craft · D9 usability(visible) · D10 token
  self-consistency. Each violation → controlled-vs-accidental call, **marked + routed to a human**.
- **Informational (never blocks):** I1 personality/character · I2 conformance/distance from exemplars.

The load-bearing rule, learned from the corpus: **the discriminator is execution + intent, never the
technique** — gradients, AI imagery, dark mode, overlap all appear in *good* designs too.

## Layout (Claude Code plugin)
```
.claude-plugin/  plugin.json (manifest) · marketplace.json (distribution)
agents/          decompose · map · judge   (+ baseline = single-pass control)
skills/          gate (orchestrator) · hard-checks · rubric-principles ·
                 annotated-exemplars (corpus.json = 23 graded designs, verbatim) ·
                 ai-slop (markers.json = single source: detection AND prevention) ·
                 design-context (Design Read + dials = single source for contextual strictness) ·
                 intent-prep (delegates craft to impeccable/awesome-design; adds calibration)
hooks/           hooks.json — SessionStart setup + PostToolUse auto-gate trigger
scripts/         render.js · hardcheck.js · wcag.js · hardcheck.test.js · eval.js ·
                 setup.mjs (idempotent deps install) · auto-gate.mjs (artifact detector → nudge)
tests/           corpus/ (fixtures) · validation/ (labeled set + results) · output/
tokens/          optional per-project token files ({ "spacing": [...] })
```

## Packaging & distribution
Shipped as a **Claude Code plugin** so non-designers install once and do nothing else:
```
/plugin marketplace add <repo-url>
/plugin install design-gate@carbonteq-design
```
Then it runs on its own — see [INSTALL.md](INSTALL.md). Skills auto-activate by description (so
"build a dashboard" pulls in the guidance), and the **PostToolUse hook** auto-nudges the gate whenever
a UI artifact (`.html`/`.jsx`/`.tsx`) is written — no manual invocation. The generation skills
(impeccable, awesome-design) are **recommended companions**, not hard dependencies: the gate works
standalone and `intent-prep` falls back gracefully if they're absent, so install never breaks.

## Run it

**Gate a design (the product):** auto-fires via the hook, or invoke `/design-gate:gate` on an
HTML/JSX file or URL.

**Deterministic layer only:**
```bash
node scripts/render.js --file path/to/design.html --out tests/output/x   # or --url / --html
node scripts/hardcheck.js --facts tests/output/x.facts.json [--tokens tokens/proj.json]
node scripts/hardcheck.test.js        # 25 unit tests for the WCAG math
```

**Evaluation (is the gate sound? is the split worth it?):**
1. Fill `tests/validation/labels.template.json` (set `verdict`+`reason` per sample) → save as `labels.json`.
2. Run `/gate` and the `baseline` agent on each sample; record `[{id, verdict}]` into
   `tests/validation/results/pipeline.json` and `…/baseline.json`.
3. `node scripts/eval.js` → agreement / false-flag / missed-failure for both, controlled-break tracked
   separately, and a pipeline-vs-baseline comparison.

## Status
- ✅ Deterministic layer built + calibrated (25 math tests pass; validation set behaves correctly:
  clean/good/lookalike/controlled pass hard-checks, accidental + slop-with-constraint-fail fail,
  slop-without-constraint-fail passes hard-checks with a default signal).
- ✅ All 4 skills, 3 subagents + baseline, orchestrator, intent-prep built.
- ✅ Exemplar bank harvested verbatim (23 designs) and grounding the rubric/exemplars.
- ⏳ **Needs Eman:** label the 7 validation samples (`labels.json`); then run the model pipeline +
  baseline and score with `eval.js`. Optional: per-project token files; a glance at the harvested
  annotations.

## Model assignment
Test/calibration phase: **Opus on every stage** (remove model choice as a confound). Production may
move Decompose to Sonnet **only after** the perception-check proves it adequate — perception is the
failure-critical stage.

## Scope (v1)
A **gate** (flag weak output, person decides — surfaced, never hard-blocked), not a coach. Trigger is
manual `/gate` + intent-prep **prevention**; no automatic output-gating yet. No fine-tuning — all
in-context grounding, so every verdict stays inspectable.
```
