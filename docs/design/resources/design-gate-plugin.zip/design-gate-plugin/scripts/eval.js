// eval.js — score the gate against Eman's labels, and compare the 3-stage pipeline to the
// single-pass baseline. Answers the core question: is the split worth its cost?
//
//   node scripts/eval.js
//
// Reads:
//   tests/validation/labels.json            (ground truth — Eman: id, verdict: pass|flag, reason)
//   tests/validation/results/pipeline.json  ([{ id, verdict }] from running /gate on each sample)
//   tests/validation/results/baseline.json  ([{ id, verdict }] from running the baseline agent)
// pipeline.json / baseline.json are optional — whichever exist get scored.

import { readFileSync, existsSync } from 'node:fs';

const norm = (v) => {
  const s = String(v || '').toLowerCase();
  if (s.startsWith('pass')) return 'pass';
  if (s.startsWith('flag')) return 'flag';
  return '';
};

const root = 'tests/validation';
if (!existsSync(`${root}/labels.json`)) {
  console.error(`No ${root}/labels.json yet.\nFill in tests/validation/labels.template.json (set verdict + reason per sample) and save it as labels.json, then re-run.`);
  process.exit(1);
}
const labels = JSON.parse(readFileSync(`${root}/labels.json`, 'utf8')).samples;
const byId = Object.fromEntries(labels.map((s) => [s.id, s]));

const unlabeled = labels.filter((s) => !norm(s.verdict));
if (unlabeled.length) {
  console.error(`These samples have no verdict yet: ${unlabeled.map((s) => s.id).join(', ')}`);
  process.exit(1);
}

function score(name, file) {
  if (!existsSync(file)) return null;
  const preds = JSON.parse(readFileSync(file, 'utf8'));
  const predById = Object.fromEntries(preds.map((p) => [p.id, norm(p.verdict)]));

  let agree = 0, total = 0, falseFlag = 0, humanPass = 0, missed = 0, humanFlag = 0;
  let cbAgree = 0, cbTotal = 0;
  const rows = [];
  for (const s of labels) {
    const truth = norm(s.verdict);
    const pred = predById[s.id];
    if (!pred) { rows.push([s.id, truth, '—', 'no prediction']); continue; }
    total++;
    const ok = pred === truth;
    if (ok) agree++;
    if (truth === 'pass') { humanPass++; if (pred === 'flag') falseFlag++; }
    if (truth === 'flag') { humanFlag++; if (pred === 'pass') missed++; }
    if (s.controlled_break) { cbTotal++; if (ok) cbAgree++; }
    rows.push([s.id, truth, pred, ok ? 'ok' : '✗ DISAGREE']);
  }
  return { name, total, agree, falseFlag, humanPass, missed, humanFlag, cbAgree, cbTotal, rows };
}

const pct = (n, d) => (d === 0 ? 'n/a' : `${Math.round((100 * n) / d)}% (${n}/${d})`);

function report(r) {
  if (!r) return;
  console.log(`\n=== ${r.name} ===`);
  for (const [id, truth, pred, note] of r.rows) {
    console.log(`  ${id.padEnd(30)} human=${truth.padEnd(5)} gate=${String(pred).padEnd(5)} ${note}`);
  }
  console.log(`  Agreement:        ${pct(r.agree, r.total)}`);
  console.log(`  False-flag rate:  ${pct(r.falseFlag, r.humanPass)}   (flagged something the human passed)`);
  console.log(`  Missed-failure:   ${pct(r.missed, r.humanFlag)}   (passed something the human flagged)`);
  console.log(`  Controlled-break: ${pct(r.cbAgree, r.cbTotal)}   (tracked separately — least reliable verdict)`);
}

const pipeline = score('pipeline (decompose→map→judge)', `${root}/results/pipeline.json`);
const baseline = score('baseline (single-pass)', `${root}/results/baseline.json`);

if (!pipeline && !baseline) {
  console.error('No predictions found. Create tests/validation/results/pipeline.json and/or baseline.json as [{ "id", "verdict" }].');
  process.exit(1);
}
report(pipeline);
report(baseline);

if (pipeline && baseline) {
  console.log('\n=== VERDICT: is the split worth it? ===');
  console.log(`  pipeline agreement ${pct(pipeline.agree, pipeline.total)}  vs  baseline ${pct(baseline.agree, baseline.total)}`);
  const diff = pipeline.agree - baseline.agree;
  console.log(diff > 0 ? `  → pipeline beats baseline by ${diff} sample(s). Split is earning its cost.`
            : diff === 0 ? '  → tie. If baseline matches the pipeline, the split may not be worth the latency/cost — investigate.'
            : `  → baseline beats pipeline by ${-diff}. Re-examine where the pipeline stages diverge.`);
}
console.log('');
