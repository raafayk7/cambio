// SessionStart setup for the design-gate plugin. Ensures the deterministic layer's deps
// (Playwright + chromium) are present. Idempotent: writes a marker and no-ops on later sessions.
// Bulletproof — never blocks session start.
import { existsSync, writeFileSync, mkdirSync } from 'node:fs';
import { execSync } from 'node:child_process';

const root = process.env.CLAUDE_PLUGIN_ROOT || process.cwd();
const dataDir = process.env.CLAUDE_PLUGIN_DATA || `${root}/.data`;
const marker = `${dataDir}/.setup-done`;

try {
  if (existsSync(marker)) process.exit(0);
  if (!existsSync(`${root}/node_modules/playwright`)) {
    execSync('npm install --omit=dev', { cwd: root, stdio: 'ignore' });
  }
  // chromium download is idempotent (fast no-op if already present)
  execSync('npx playwright install chromium', { cwd: root, stdio: 'ignore' });
  mkdirSync(dataDir, { recursive: true });
  writeFileSync(marker, 'design-gate setup complete');
} catch {
  // leave no marker so it retries next session; never throw
}
process.exit(0);
