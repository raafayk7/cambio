# Design Gate — install (for everyone, no setup)

You install one thing. After that it works on its own — you don't run any commands.

## Install from the file you were sent (Slack)

1. **Save & unzip** `design-gate-plugin.zip` somewhere stable (e.g. `~/design-gate-plugin`). You'll
   get a folder with a `.claude-plugin/` inside it.
2. In Claude Code, point it at that folder and install:

```
/plugin marketplace add ~/design-gate-plugin
/plugin install design-gate@carbonteq-design
```

3. Reload when prompted (`/reload-plugins`). That's it.

> Use the real path where you unzipped it. Keep the folder around — don't delete it after installing.

> First time only: the gate quietly downloads a small headless browser it uses to measure your
> designs ("Preparing the design gate…"). You don't do anything — just let it finish.

## What happens automatically (you do nothing)

- **When you ask Claude to build UI** ("make a dashboard", "design a landing page"), it automatically
  pulls in the design guidance so the output starts better.
- **When a design is produced** (an `.html` page, a component), the gate automatically reviews it and
  shows you a verdict inline:
  - ✅ **Pass**, or ⚠️ **Flagged** with a short list of located problems and concrete fixes.
  - It **never blocks you** — it surfaces the design and the critique, and you decide: use it, revise
    it, or tell Claude "fix the flagged points."

## What it checks

- **Accessibility** (measured, not guessed): text contrast, tap-target sizes.
- **AI-slop**: gradient text, emoji-as-icons, generic templated patterns, etc.
- **Design principles**: hierarchy, spacing, typography, restraint — judged in context (a dense
  dashboard and a bold landing page are held to different, appropriate standards).

## Get the full craft lift (recommended companions)

The gate *verifies* designs. To make the designs themselves much better at creation time, also install
a generation skill — the gate will automatically use it:

- **impeccable** — the main craft engine (distinctive type, color, layout; anti-slop).
- **awesome-design** — brand reference library (build "Stripe-style", "Linear-style", etc.).
- *(or taste-skill as an alternative to impeccable — don't run both.)*

If none are installed, the gate still works and still steers generation with its built-in guidance —
you just get a bit less of the creation-time lift.

## Asking for a review manually

You normally don't need to, but you can always say "**run the design gate on this**" or
`/design-gate:gate` on any `.html` file or URL.
